package com.fastcampus.ch4;

import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, String> {}