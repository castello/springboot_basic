package com.fastcampus.ch3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
